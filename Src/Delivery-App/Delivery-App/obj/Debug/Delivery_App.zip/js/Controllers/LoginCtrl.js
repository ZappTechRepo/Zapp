app.controller('LoginCtrl', function ($scope, $stateParams, Utils, baseUrl, $cordovaDialogs, $localStorage, profileService, $http, $state) {
    Utils.SetStatusBarColor('#00aba9');
    $scope.loginData = {
        userName: "",
        password: ""
    };

    $scope.Login = function () { 

        if ($scope.loginData.userName != "" && $scope.loginData.password != "") {

            profileService.DoLogin($scope.loginData).success(function (data) {
                console.log(data);
                $localStorage.Profile = data;
                $state.go('app.deliveries', { userId: $localStorage.Profile.UserID });
            }).error(function (data) {
                $cordovaDialogs.alert(data.Message, 'Login', 'OK');
            });

        } else {
            $cordovaDialogs.alert('Enter your full login details. ', 'Login', 'OK');
        }
    }


    $scope.doLoginFromToken = function (token) {

        $http.post(baseUrl + "/Auth/doLoginFromToken", { token: token }).success(function (data) {

            profileService.SetProfile(data);
            $state.go('app.profile');

        }).error(function (data) {
            console.dir(data);
            $cordovaDialogs.alert('Unable to log you in. ' + data, 'Login', 'OK');
        });
    };

    //initialization
    var profile = profileService.getProfile();
    if (profile != null) {
        $scope.doLoginFromToken(profileService.getToken());
    }
});