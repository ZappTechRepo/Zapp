// ====================== GLOBAL VARIABLES (VALUES)
//dev
app.value('baseUrl', 'https://randomuser.me/api/');


app.value('http_defaults', { timeout: 15000 }); //15 seconds 