// ====================== GLOBAL VARIABLES (VALUES)
//Live
app.value('baseUrl', 'http://trib.tarsusonline.co.za/');

//Local 
//app.value('baseUrl', 'http://localhost:29128/');

//app.value('baseUrl', 'http://192.168.0.115/TriboschAdmin/');

app.value('http_defaults', { timeout: 15000 }); //15 seconds  